const AWS = require('aws-sdk');
exports.handler = async (event) => {
    let code = event.queryStringParameters.code;
    var docClient = new AWS.DynamoDB.DocumentClient();

    var params = {
        TableName: 'filedata',
        KeyConditionExpression: '#HashKey = :hkey',
        ExpressionAttributeNames: { '#HashKey': 'code' },
        ExpressionAttributeValues: {
            ':hkey': code
        }
    };
    try {
        const result = await docClient.query(params).promise();

        if (result.Items.length < 1) {
            let response = {
                isBase64Encoded: true,
                statusCode: 200,
                headers: {
                    "Content-Type": "application/json; charset=utf-8",
                    "Access-Control-Expose-Headers": "*",
                    "Access-Control-Allow-Origin": "*",
                },
                body: JSON.stringify({ url: "none" })
            };
            return response
        }
        const fileData = result.Items[0];
        const s3 = new AWS.S3({});

        const s3Params = {
            Bucket: fileData.bucket,
            Key: fileData.key,
            Expires: 600,
        }

        const url = s3.getSignedUrl("getObject", s3Params)
        let response = {
            isBase64Encoded: true,
            statusCode: 200,
            headers: {
                "Content-Type": "application/json; charset=utf-8",
                "Access-Control-Expose-Headers": "*",
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify({ url: url })
        };
        return response
    }
    catch (e) {
        console.log(e)
        let response = {
            isBase64Encoded: true,
            statusCode: 500,
            headers: {
                "Content-Type": "application/json; charset=utf-8",
                "Access-Control-Allow-Origin": "*",
            },
            body: JSON.stringify("error")
        };
        //console.log(response);
        return response;
    }

};